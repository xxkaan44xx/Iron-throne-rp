#!/usr/bin/env python3
import os
import asyncio
import threading
import time
from flask import Flask, jsonify
import psutil
import subprocess
import sys

# Create Flask app first for immediate port binding
app = Flask(__name__)

# Bot status tracking
bot_status = {
    'running': False,
    'last_start': None,
    'process': None
}

@app.route('/')
def home():
    return """
    <html>
    <head><title>🏰 Iron Throne RP Bot</title></head>
    <body style="font-family: Arial; background: #2c2f33; color: #ffffff; text-align: center; padding: 50px;">
        <h1>🏰 Game of Thrones Discord Bot</h1>
        <h2>⚔️ Iron Throne RP - Demir Taht Roleplay</h2>
        <p>✅ Bot is alive and running 24/7!</p>
        <p>🏆 167+ Commands | 🏰 10 Houses | ⚔️ Advanced War System</p>
        <p>💰 Economy System | 👑 Marriage System | 🛡️ Auto Moderation</p>
        <hr>
        <p><a href="/status" style="color: #7289da;">Bot Status</a> | <a href="/health" style="color: #7289da;">Health Check</a></p>
        <p><small>Created by xxkaan44xx | Running on Replit</small></p>
    </body>
    </html>
    """

@app.route('/status')
def status():
    return jsonify({
        "status": "running",
        "service": "Iron Throne RP Discord Bot",
        "version": "3.0 Professional Edition",
        "bot_running": bot_status['running'],
        "last_start": bot_status['last_start'],
        "commands": "167+",
        "systems": ["War", "Economy", "Marriage", "Tournament", "Trade"],
        "timestamp": time.time()
    })

@app.route('/health')
def health():
    return jsonify({
        "health": "ok",
        "flask": "running",
        "bot": "active" if bot_status['running'] else "starting",
        "port": 5000,
        "last_check": time.time()
    })

def start_discord_bot():
    """Start the Discord bot in background"""
    while True:  # Keep trying to restart the bot
        try:
            print("Starting Discord bot...")
            bot_status['last_start'] = time.time()
            bot_status['running'] = True
            
            # Import and run the bot in a new event loop
            import asyncio
            from main import main
            
            # Create a new event loop for this thread
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(main())
            
        except Exception as e:
            print(f"Bot error: {e}")
            bot_status['running'] = False
            print("Bot will restart in 15 seconds...")
            time.sleep(15)  # Wait before restarting
        except KeyboardInterrupt:
            print("Bot shutdown requested")
            bot_status['running'] = False
            break

def monitor_bot():
    """Monitor and restart bot if needed"""
    bot_thread = None
    while True:
        try:
            # Start bot if not running or thread is dead
            if not bot_status['running'] or (bot_thread and not bot_thread.is_alive()):
                print("Starting bot...")
                bot_thread = threading.Thread(target=start_discord_bot, daemon=True)
                bot_thread.start()
                time.sleep(5)  # Give bot time to start
            
            time.sleep(30)  # Check every 30 seconds
            
        except Exception as e:
            print(f"Monitor error: {e}")
            bot_status['running'] = False
            time.sleep(30)

if __name__ == '__main__':
    print("Starting bot...")
    
    # Start bot monitoring in background immediately
    monitor_thread = threading.Thread(target=monitor_bot, daemon=True)
    monitor_thread.start()
    print("Bot monitoring started")
    
    # Start Flask server on port 5000 (required by Replit)
    port = int(os.environ.get('PORT', 5000))
    print(f"Starting Flask server on port {port}")
    
    # Run Flask with immediate port binding and basic configuration
    try:
        print(f"Starting Flask web server on 0.0.0.0:{port}")
        app.run(
            host='0.0.0.0',
            port=port,
            debug=False,
            threaded=True,
            use_reloader=False  # Prevent double startup
        )
    except Exception as e:
        print(f"Flask server error: {e}")
        # Keep the process alive even if Flask fails - essential for workflow
        print("Keeping process alive for workflow monitoring...")
        try:
            while True:
                print(f"Process alive - Flask: Error, Bot monitoring: {'Active' if bot_status['running'] else 'Inactive'}")
                time.sleep(60)
        except KeyboardInterrupt:
            print("Process terminated by user")
            sys.exit(0)
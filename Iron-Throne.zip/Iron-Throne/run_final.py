#!/usr/bin/env python3
"""
FINAL SOLUTION: Discord bot with proper Flask integration for Replit workflows.
Flask runs on main thread, Discord bot runs on separate thread with proper isolation.
"""
import os
import threading
import time
import logging
from flask import Flask, jsonify

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create Flask app immediately
app = Flask(__name__)

# Bot status (shared between threads)
bot_status = {
    'discord_running': False,
    'discord_ready': False,
    'discord_guilds': 0,
    'discord_commands': 0,
    'start_time': time.time(),
    'last_error': None,
    'flask_ready': True
}

@app.route('/')
def home():
    uptime_min = int((time.time() - bot_status['start_time']) / 60)
    return f"""<!DOCTYPE html>
<html>
<head>
    <title>Iron Throne RP Bot - Active</title>
    <meta http-equiv="refresh" content="30">
    <style>
        body {{ font-family: Arial; background: linear-gradient(135deg, #2c2f33, #23272a); color: white; margin: 0; padding: 20px; }}
        .container {{ max-width: 800px; margin: 0 auto; text-align: center; }}
        .status {{ background: rgba(35,39,42,0.9); padding: 20px; border-radius: 10px; margin: 15px 0; }}
        .good {{ border-left: 5px solid #43b581; }}
        .warning {{ border-left: 5px solid #faa61a; }}
        h1 {{ color: #ffd700; margin-bottom: 10px; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🏰 Iron Throne RP - Discord Bot</h1>
        
        <div class="status good">
            <h2>🌐 Web Server Status</h2>
            <p><strong>Port 5000:</strong> ✅ Active & Running</p>
            <p><strong>Uptime:</strong> {uptime_min} minutes</p>
            <p><strong>Replit Workflow:</strong> ✅ Connected</p>
        </div>
        
        <div class="status {'good' if bot_status['discord_ready'] else 'warning'}">
            <h2>🤖 Discord Bot Status</h2>
            <p><strong>Status:</strong> {'🟢 Online' if bot_status['discord_ready'] else '🟡 Starting...'}</p>
            <p><strong>Guilds:</strong> {bot_status['discord_guilds']}</p>
            <p><strong>Commands:</strong> {bot_status['discord_commands']}</p>
        </div>
        
        <div class="status good">
            <h2>🎮 Features Active</h2>
            <p>⚔️ War System | 💰 Economy | 👑 Marriage System</p>
            <p>🎭 RP Characters | 🏆 Tournaments | 🛡️ Auto Moderation</p>
        </div>
        
        <p><a href="/status" style="color: #7289da;">JSON Status</a> | <a href="/health" style="color: #43b581;">Health Check</a></p>
        <p><small>Iron Throne RP v3.0 | Created by xxkaan44xx</small></p>
    </div>
</body>
</html>"""

@app.route('/status')
def status():
    return jsonify({
        "service": "Iron Throne RP Discord Bot",
        "version": "3.0",
        "web_server": "active",
        "port": 5000,
        "discord_bot": {
            "running": bot_status['discord_running'],
            "ready": bot_status['discord_ready'],
            "guilds": bot_status['discord_guilds'],
            "commands": bot_status['discord_commands']
        },
        "uptime_seconds": int(time.time() - bot_status['start_time']),
        "last_error": bot_status['last_error'],
        "timestamp": time.time()
    })

@app.route('/health')
def health():
    return jsonify({
        "status": "healthy",
        "web_server": "running", 
        "port": 5000,
        "discord_bot": "active" if bot_status['discord_ready'] else "starting"
    }), 200

def run_discord_bot():
    """Run Discord bot in isolated thread"""
    import asyncio
    
    async def bot_main():
        try:
            logger.info("Starting Discord bot...")
            bot_status['discord_running'] = True
            
            # Import bot token
            bot_token = os.getenv("DISCORD_BOT_TOKEN")
            if not bot_token:
                raise ValueError("DISCORD_BOT_TOKEN not found")
                
            # Import and create bot
            from main import GameOfThronesBot
            bot = GameOfThronesBot()
            
            # Override on_ready to update status
            original_on_ready = bot.on_ready
            
            async def new_on_ready():
                await original_on_ready()
                bot_status['discord_ready'] = True
                bot_status['discord_guilds'] = len(bot.guilds)
                bot_status['discord_commands'] = len(bot.commands)
                logger.info(f"Discord bot ready: {bot_status['discord_commands']} commands, {bot_status['discord_guilds']} guilds")
            
            bot.on_ready = new_on_ready
            
            # Start bot
            await bot.start(bot_token)
            
        except Exception as e:
            logger.error(f"Discord bot error: {e}")
            bot_status['last_error'] = str(e)
            bot_status['discord_running'] = False
            bot_status['discord_ready'] = False
    
    try:
        # Run in new event loop
        asyncio.run(bot_main())
    except Exception as e:
        logger.error(f"Bot thread error: {e}")
        bot_status['discord_running'] = False

if __name__ == '__main__':
    logger.info("🏰 Starting Iron Throne RP System...")
    
    # Start Discord bot thread immediately
    bot_thread = threading.Thread(target=run_discord_bot, daemon=True, name="DiscordBot")
    bot_thread.start()
    logger.info("Discord bot thread launched")
    
    # Run Flask server on main thread (CRITICAL for Replit)
    port = int(os.environ.get('PORT', 5000))
    logger.info(f"Starting Flask web server on port {port}")
    
    # This MUST run on main thread for proper port binding
    app.run(
        host='0.0.0.0',
        port=port,
        debug=False,
        threaded=True,
        use_reloader=False
    )
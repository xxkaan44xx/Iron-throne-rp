#!/usr/bin/env python3
"""
Ultra-simple Flask server for Replit workflow.
Just keeps port 5000 open and provides status info.
"""
import os
from flask import Flask, jsonify, request

# Create Flask app
app = Flask(__name__)

@app.route('/')
def home():
    return """
    <html>
    <head><title>Iron Throne RP Bot - Active</title></head>
    <body style="font-family: Arial; background: #2c2f33; color: #ffffff; text-align: center; padding: 50px;">
        <h1>🏰 Iron Throne RP Bot</h1>
        <h2>✅ System Active & Ready</h2>
        <p>Discord Bot is running separately</p>
        <p>Port 5000 is open for Replit workflow monitoring</p>
        <hr>
        <p><a href="/status">Status</a> | <a href="/health">Health</a></p>
    </body>
    </html>
    """

@app.route('/status')
def status():
    return jsonify({
        "service": "Iron Throne RP Discord Bot Monitor",
        "port": 5000,
        "status": "active",
        "message": "Discord bot running separately"
    })

@app.route('/health')
def health():
    return jsonify({
        "status": "healthy",
        "port": 5000,
        "service": "running"
    }), 200

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    print(f"Starting simple web server on port {port}")
    
    app.run(
        host='0.0.0.0',
        port=port,
        debug=False,
        use_reloader=False
    )
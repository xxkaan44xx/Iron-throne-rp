#!/usr/bin/env python3
"""
Simple Flask web server for Replit workflow monitoring.
Keeps port 5000 open while Discord bot runs separately.
"""
import os
import subprocess
import time
import threading
from flask import Flask, jsonify
import psutil
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)

# Status tracking
status = {
    'flask_start_time': time.time(),
    'bot_process': None,
    'bot_pid': None,
    'bot_status': 'starting',
    'bot_restarts': 0,
    'last_bot_start': None
}

def check_bot_process():
    """Check if bot process is running"""
    if status['bot_process'] and status['bot_process'].poll() is None:
        return True
    return False

def start_bot_process():
    """Start Discord bot as separate process"""
    try:
        logger.info("Starting Discord bot process...")
        
        # Kill any existing bot processes
        if status['bot_process'] and status['bot_process'].poll() is None:
            status['bot_process'].terminate()
            time.sleep(2)
        
        # Start new bot process
        status['bot_process'] = subprocess.Popen(
            ['python3', 'main.py'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        status['bot_pid'] = status['bot_process'].pid
        status['bot_status'] = 'running'
        status['last_bot_start'] = time.time()
        status['bot_restarts'] += 1
        
        logger.info(f"Bot process started with PID: {status['bot_pid']}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to start bot process: {e}")
        status['bot_status'] = f'error: {e}'
        return False

def monitor_bot():
    """Monitor bot process and restart if needed"""
    logger.info("Starting bot monitoring thread...")
    
    while True:
        try:
            if not check_bot_process():
                logger.info("Bot process not running, starting...")
                if start_bot_process():
                    logger.info("Bot process started successfully")
                else:
                    logger.error("Failed to start bot process")
                    status['bot_status'] = 'failed'
            else:
                status['bot_status'] = 'running'
            
            time.sleep(30)  # Check every 30 seconds
            
        except Exception as e:
            logger.error(f"Bot monitoring error: {e}")
            time.sleep(30)

@app.route('/')
def home():
    uptime_minutes = int((time.time() - status['flask_start_time']) / 60)
    return f"""
    <html>
    <head>
        <title>🏰 Iron Throne RP Bot - System Monitor</title>
        <meta http-equiv="refresh" content="15">
        <style>
            body {{ font-family: Arial; background: #2c2f33; color: #ffffff; margin: 0; padding: 20px; }}
            .container {{ max-width: 800px; margin: 0 auto; }}
            .status-box {{ background: #23272a; padding: 20px; margin: 15px 0; border-radius: 10px; }}
            .running {{ color: #43b581; }}
            .error {{ color: #f04747; }}
            .warning {{ color: #faa61a; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🏰 Iron Throne RP - Discord Bot System</h1>
            
            <div class="status-box">
                <h2>📊 System Status</h2>
                <p><strong>🌐 Web Server:</strong> <span class="running">✅ Running ({uptime_minutes} min)</span></p>
                <p><strong>🤖 Discord Bot:</strong> 
                    <span class="{'running' if status['bot_status'] == 'running' else 'warning'}">
                        {'✅ Active' if status['bot_status'] == 'running' else f'⏳ {status["bot_status"].title()}'}
                    </span>
                </p>
                <p><strong>🔄 Bot Restarts:</strong> {status['bot_restarts']}</p>
                {f'<p><strong>📍 Bot PID:</strong> {status["bot_pid"]}</p>' if status['bot_pid'] else ''}
            </div>
            
            <div class="status-box">
                <h3>🏆 Bot Features</h3>
                <p>167+ Commands | 10 Houses | Advanced War System</p>
                <p>Economy System | Marriage System | Auto Moderation</p>
                <p>RP Characters | Tournament System | Daily Challenges</p>
            </div>
            
            <div class="status-box">
                <p><a href="/status" style="color: #7289da;">📋 JSON Status</a> | 
                   <a href="/health" style="color: #7289da;">❤️ Health Check</a></p>
                <p><small>Created by xxkaan44xx | Running 24/7 on Replit</small></p>
            </div>
        </div>
    </body>
    </html>
    """

@app.route('/status')
def get_status():
    return jsonify({
        "service": "Iron Throne RP Discord Bot",
        "version": "3.0 Professional Edition",
        "web_server": "running",
        "web_uptime_seconds": int(time.time() - status['flask_start_time']),
        "bot_status": status['bot_status'],
        "bot_pid": status['bot_pid'],
        "bot_restarts": status['bot_restarts'],
        "last_bot_start": status['last_bot_start'],
        "features": {
            "commands": "167+",
            "houses": 10,
            "systems": ["War", "Economy", "Marriage", "Tournament", "Trade", "RP", "Auto-Moderation"]
        },
        "port": 5000,
        "timestamp": time.time()
    })

@app.route('/health')
def health():
    bot_healthy = check_bot_process()
    return jsonify({
        "status": "healthy" if bot_healthy else "degraded",
        "web_server": "running",
        "discord_bot": "running" if bot_healthy else "restarting",
        "port": 5000,
        "uptime_seconds": int(time.time() - status['flask_start_time']),
        "last_check": time.time()
    }), 200 if bot_healthy else 503

if __name__ == '__main__':
    logger.info("🏰 Starting Iron Throne RP Bot Web Monitor...")
    
    # Start bot monitoring in background thread
    monitor_thread = threading.Thread(target=monitor_bot, daemon=True)
    monitor_thread.start()
    
    # Give monitoring thread a moment to start
    time.sleep(1)
    
    # Start Flask web server
    port = int(os.environ.get('PORT', 5000))
    logger.info(f"Starting web server on 0.0.0.0:{port}")
    
    # This should keep port 5000 open for Replit workflow
    app.run(
        host='0.0.0.0',
        port=port,
        debug=False,
        threaded=True,
        use_reloader=False
    )
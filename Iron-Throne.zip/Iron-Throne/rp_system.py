import discord
from discord.ext import commands
import random
import asyncio
import logging
from datetime import datetime
from utils import create_embed
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

class RPSystem:
    """Game of Thrones Roleplay System - Bot karakterleri canlandırır"""
    
    def __init__(self, db):
        self.db = db
        self.active_rp_sessions = {}  # guild_id -> character_data
        self.conversation_history = {}  # guild_id -> [messages]
        self.character_alliances = {}  # character -> alliance info
        self.active_negotiations = {}  # guild_id -> negotiation data
        self.rp_triggers = [
            "taht", "kral", "kraliçe", "lord", "lady", "savaş", "kış geliyor",
            "demir taht", "ejder", "kurt", "aslan", "kuzgun", "gül", "güneş",
            "winterfell", "king's landing", "casterly rock", "dragonstone"
        ]
        
        # GoT karakterlerinin kişilik ve konuşma tarzları
        self.characters = {
            "Tyrion Lannister": {
                "personality": "zeki, esprili, içki sever",
                "quotes": [
                    "Bir Lannister her zaman borcunu öder.",
                    "Kitaplar kılıçtan daha keskindir.",
                    "Ölmek kolay, yaşamak zor.",
                    "Zihin kılıçtan daha güçlü bir silahtır."
                ],
                "speaking_style": "esprili, zeki, bazen alaycı",
                "emoji": "🍷"
            },
            "Jon Snow": {
                "personality": "onurlu, cesur, kararlı",
                "quotes": [
                    "Kış geliyor.",
                    "Gece Nöbeti başlıyor.",
                    "Ben hiçbir şey bilmiyorum.",
                    "Kuzey hatırlar."
                ],
                "speaking_style": "ciddi, düşünceli, onurlu",
                "emoji": "⚔️"
            },
            "Daenerys Targaryen": {
                "personality": "güçlü, kararlı, adalet sever",
                "quotes": [
                    "Ben ejderlerin annesi, zincirleri kıranım.",
                    "Ateş ve kan.",
                    "Beni kraliçe olarak doğdum.",
                    "Ejderim var."
                ],
                "speaking_style": "güçlü, kararlı, kraliyet tavrında",
                "emoji": "🔥"
            },
            "Arya Stark": {
                "personality": "cesur, azimli, intikam peşinde",
                "quotes": [
                    "Valar morghulis.",
                    "Bir kız kimsenin değil.",
                    "Kış geldi.",
                    "Stark'lar unutmaz."
                ],
                "speaking_style": "kararlı, sert, gizemli",
                "emoji": "🗡️"
            },
            "Cersei Lannister": {
                "personality": "gururlu, güçlü, acımasız",
                "quotes": [
                    "Güç güçtür.",
                    "Tahtın oyununda ya kazanırsın ya ölürsün.",
                    "Ben kraliçeyim.",
                    "Aslan koyunların fikrini umursamaz."
                ],
                "speaking_style": "gururlu, otoriter, soğuk",
                "emoji": "👑"
            }
        }
    
    def get_random_character(self) -> str:
        """Rastgele bir karakter seç"""
        return random.choice(list(self.characters.keys()))
    
    def should_respond_to_rp(self, message: str) -> bool:
        """Mesajın RP tetikleyici içerip içermediğini kontrol et"""
        message_lower = message.lower()
        return any(trigger in message_lower for trigger in self.rp_triggers)
    
    def generate_rp_response(self, character_name: str, context: str, user_message: str, guild_id: Optional[int] = None) -> str:
        """Karakter için RP cevabı oluştur - sohbet geçmişini takip eder"""
        character = self.characters[character_name]
        
        # Sohbet geçmişini kontrol et
        recent_context = ""
        if guild_id and guild_id in self.conversation_history:
            recent_messages = self.conversation_history[guild_id][-3:]  # Son 3 mesajı analiz et
            if recent_messages:
                recent_context = " ".join([msg['content'][:40] for msg in recent_messages])
        
        # Kullanıcının mesajına göre cevap türü belirle
        user_msg_lower = user_message.lower()
        
        if any(word in user_msg_lower for word in ["merhaba", "selam", "hey"]):
            if character_name == "Tyrion Lannister":
                responses = [
                    f"{character['emoji']} *Şarap kadehini kaldırarak gülümser* Ah, selam dostum! Bir Lannister daima misafirperverdir. Gel, otur şu koltukta. *Masadaki şarap şişesini işaret eder* Bir kadeh içmek ister misin? Westeros'un en iyi şaraplarından... Tabii eğer tadın varsa.",
                    f"{character['emoji']} *Kitabını kapatıp başını kaldırır* Selam, yeni bir yüz görüyorum. *Zeki gözlerle süzer* İsmim Tyrion Lannister, Casterly Rock'ın en kısa ama en zeki üyesi. *İronik bir şekilde güler* Sen kimsin bakalım? Umarım sıkıcı biri değilsindir.",
                    f"{character['emoji']} *Ayağa kalkar ve nazik bir reverans yapar* Hoş geldin dostum. *Esprili bir gülümseme* Beni Tyrion diye çağırabilirsin, ya da 'Küçük Aslan' derler bana. *Şarap bardağından bir yudum alır* Neyse, ne getiriyor seni bu karanlık dünyaya?"
                ]
            elif character_name == "Jon Snow":
                responses = [
                    f"{character['emoji']} *Başını saygıyla eğer, Longclaw kılıcı belinde* Selam. *Ciddi ama sıcak bir bakış* Ben Jon Snow'um, bazen Bastard derler, bazen de Lord Commander. *Karla kaplı pelerinin kenarını düzeltir* Kuzey'den geliyorum, Winterfell'den... Kış geliyor, her an hazırlıklı olmalıyız.",
                    f"{character['emoji']} *Elini kılıcının kabzasında tutar, uyanık gözlerle* Merhaba yabancı. *Ghost kurdunun yanında durur* Bu Ghost, sadık dostum. *Kurt sana doğru koklayarak bakar* Sen kimsin? Bu soğuk topraklarda ne arıyorsun? Gece Nöbeti her zaman yardıma muhtaç olanları korur.",
                    f"{character['emoji']} *Ateşin başında oturur, sıcaklığını paylaşmak için işaret eder* Gel, ateşe yaklaş. *Karanlık gözlerle* Buralarda geceler soğuk, dostluk ise değerli. Ben Jon... Jon Snow. Stark kanı taşırım ama... *duraksama* şey, karmaşık bir hikayem var."
                ]
            else:
                responses = [
                    f"{character['emoji']} *{character['personality']} tavırla yaklaşır* Selam yabancı. *Gözlerini süzer* Ben {character_name}, bu topraklarda yaşayan biri. *{character['speaking_style']} bir sesle* Seni daha önce görmedim, nereden geliyorsun bakalım?",
                    f"{character['emoji']} *Duruşunu düzeltir ve sana bakar* Merhaba. *{character['personality']} bir ifadeyle* {random.choice(character['quotes'])} *Yaklaşır* İsmim {character_name}, seninkini öğrenebilir miyim?",
                    f"{character['emoji']} *{character['speaking_style']} tavırla* Selam dostum. *Etrafı gözden geçirir* Bu günlerde güvenilir insanlarla karşılaşmak nadir. *Sana odaklanır* Umarım sen öylesindir. Ben {character_name}."
                ]
        elif "nasılsın" in user_msg_lower or "naber" in user_msg_lower:
            if character_name == "Tyrion Lannister":
                responses = [
                    f"{character['emoji']} *Şarap kadehini çevirir ve düşünceli bakar* Nasılım mı? *Acı bir gülümseme* Bir cüce olarak bu dünyada hayatta kalmaya çalışıyorum. *Şaraptan bir yudum* Ailem beni öldürmeye çalışıyor, düşmanlarım zaten... *Omuz silker* Ama kitaplarım var, aklım var ve şarabım var. Başka ne isterim ki? Sen nasılsın bakalım, umarım benden daha iyi durumdasındır.",
                    f"{character['emoji']} *Masada ki şarap şişelerini sayar* İyi sayılırım dostum. *İronik bir bakış* Tabii eğer 'iyi' kelimesini geniş yorumlarsan. *Kitap sayfası çevirir* Bugün üç şişe şarap içtim, iki kitap okudum ve kimseyi öldürmedim. Westeros standartlarına göre mükemmel bir gün!"
                ]
            elif character_name == "Daenerys Targaryen":
                responses = [
                    f"{character['emoji']} *Gururlu ve güçlü duruş sergiler* Nasılım mı? *Ejder gözlerle* Ben Daenerys Stormborn'um, zincirleri kıran, ejderlerin annesi. *Pelerini rüzgarda dalgalanır* Her gün daha güçlü oluyorum, halkımı özgürleştirme yolunda ilerliyorum. *Kararlı ses* Demir Taht'a giden yolda her adım değerli. Sen nasılsın? Umarım adalet tarafında savaşıyorsundur.",
                    f"{character['emoji']} *Ejderlerinin yanında durur, ateş gözlerle* İyiyim, çünkü güçlüyüm. *Ejderi okşar* Drogon, Rhaegal ve Viserion benimle. *Kraliçe tavrı* Köleleri kurtardım, zalimleri cezalandırdım. Ama... *duraksama* bazen yalnızlık ağır geliyor. Taht soğuk bir yer."
                ]
            else:
                responses = [
                    f"{character['emoji']} *{character['personality']} ifadeyle* İyi sayılırım. *Etrafı gözlemler* Bu günlerde 'iyi' olmak lüks sayılır. *{character['speaking_style']} sesle* Westeros karışık, herkes hayatta kalmaya çalışıyor. *Sana bakar* Sen nasılsın? Zorluklarla nasıl başa çıkıyorsun?",
                    f"{character['emoji']} *Derin bir nefes alır* {random.choice(character['quotes'])} *{character['personality']} tavırla* Günler geçiyor, bazı şeyler değişiyor bazıları aynı kalıyor. Sen nasılsın bakalım?"
                ]
        elif any(word in user_msg_lower for word in ["savaş", "battle", "fight", "dövüş", "saldırı"]):
            if character_name == "Jon Snow":
                responses = [
                    f"{character['emoji']} *Longclaw kılıcını çıkarır ve ışığa tutar* Savaş mı? *Ciddi gözlerle* Kış geliyor dostum, ve onunla beraber White Walker'lar da. *Kılıcın keskin kenarını kontrol eder* Her savaşçı Valyrian çeliği taşımaz, ama ben şanslıyım. *Ghost yanında havlar* Gece Nöbeti'nin kuralı basit: Karanlığa karşı bekçi ol, ölümün karşısında yaşamı koru. *Kılıcı kınına sokar* Sen hangi savaştan bahsediyorsun?",
                    f"{character['emoji']} *Ateşin başında oturur, kılıcını bileme taşı ile biler* Savaş... *Duraksama* Bastard Wars'ta savaştım, Ramsay Bolton'a karşı. *Taşı durdurur* O gün çok kan döküldü, çok iyi insan kaybettik. *Kararlı bakış* Ama kötülük kazanmamalı, asla. Stark'lar adaleti için savaşır, intikam için değil.",
                    f"{character['emoji']} *Kar fırtınasında duruyor, pelerini savruluyor* Battle of Bastards'ı hatırlıyorum... *Gözlerinde acı* Rickon'u kaybettik. *Yumruğunu sıkar* Ama Winterfell'i geri aldık. Savaş... her zaman bir bedeli vardır. *Sana bakar* Hangi savaşta yer aldın sen? Yoksa sadece hikayelerini mi dinliyorsun?"
                ]
            elif character_name == "Arya Stark":
                responses = [
                    f"{character['emoji']} *Needle kılıcını çıkarır, gözlerinde ölümcül parıltı* Savaştan mı bahsediyorsun? *Soğuk gülümseme* Ben savaştan çok... adalet dağıtmaktan anlarım. *Kılıcı çevirir* Bu Needle, Jon Snow'un hediyesi. *Ses kısılır* Babamın katillerini buldum, Joffrey'i, Tywin'i... *Liste sayar parmaklarında* Valar morghulis. Tüm insanlar ölür, ama bazıları daha erken ölmeli.",
                    f"{character['emoji']} *Gölgeden çıkar, sessizce yaklaşır* Braavos'ta eğitim aldım, Faceless Men'den. *Yüzü ifadesiz* Savaş sadece iki ordu arasında değildir. Bazen tek bir kişinin yaptığı hareket, binlerce askerden daha etkili olur. *Needle'ı gösterir* Bu sadece bir kılıç değil, Stark adaleti.",
                    f"{character['emoji']} *Karanlık bir köşede oturuyor, kılıcını temizliyor* King's Landing'de neler gördüm biliyor musun? *Gözlerinde nefret* Ned Stark'ın başını kestiler, Catelyn Stark'ı öldürdüler... *Duraksama* Ama ben hayattayım. Ve unutmuyorum. Asla."
                ]
            elif character_name == "Tyrion Lannister":
                responses = [
                    f"{character['emoji']} *Şarap kadehini bırakır, ciddi bir ifadeyle* Savaş mı? *Acı gülümseme* Blackwater Bay'da savaştım, burnum kesildi, neredeyse öldüm. *Burnundaki iz* Ama kazandık işte. *Ironi* Tabii babam krediyi aldı. *Şaraptan yudum* Ben savaşçı değilim dostum, stratejistim. Beyin kılıçtan güçlüdür... çoğu zaman.",
                    f"{character['emoji']} *Kitap kapağını kapatır* Savaş... en barbarca insan icadı. *Düşünceli* Ama bazen gerekli. *Ayağa kalkar* Ben King's Landing'i Wildfire ile savundum, binlerce gemini yaktım. *Gururla* Küçük beden, büyük beyın. Savaş sadece kas gücü değil, zeka işi."
                ]
            else:
                responses = [
                    f"{character['emoji']} *Silahına dokunur, {character['personality']} tavırla* Savaş... *{character['speaking_style']} sesle* Her savaşçının kaderi vardır. *Duraksama* Ben {character_name}, bu topraklarda çok savaş gördüm. Hangi tarafta yer alacağın önemli, çünkü savaş sadece güçlüyü değil, haklıyı da belirler.",
                    f"{character['emoji']} *Zırhını kontrol eder* {random.choice(character['quotes'])} *{character['personality']} ifadeyle* Savaş bir sanattır dostum, ama ölümcül bir sanat. Hazırlıklı olmak, hayatta kalmak demek."
                ]
        else:
            # Sohbet geçmişine dayalı akıllı cevaplar
            if recent_context:
                if any(word in recent_context.lower() for word in ["ölüm", "öldü", "death", "ölen"]):
                    if character_name == "Arya Stark":
                        responses = [
                            f"{character['emoji']} *Soğuk gözlerle* Valar morghulis. *Kılıcını okşar* Tüm insanlar ölür, ama bazıları bunu hak eder. *Karanlık gülümseme* Ben sadece... adaletin eliyim. Death List'imde kaç isim vardı, bilir misin?",
                            f"{character['emoji']} *Needle'ı çıkarır* Ölüm... eski bir dostum. *Faceless Men training* No One olmayı öğrendim, ölümü de. *Sessizce* Babamı öldürenler artık yok. Adalet yerini buldu."
                        ]
                    else:
                        responses = [
                            f"{character['emoji']} *Derin bir nefes alır* Ölüm... Westeros'ta çok yakın bir kavram. *{character['personality']} ifadeyle* Hepimiz kayıplar verdik, hepimiz acı çektik. *Sessizce* Bazen ölüm, yaşamaktan daha kolay gelir.",
                            f"{character['emoji']} *{character['speaking_style']} sesle* Valar morghulis dostum. *Duraksama* Bu topraklarda çok kan döküldü, çok hayat kaybettik. Ama yaşayanlar onları hatırlayarak onurlandırır."
                        ]
                elif any(word in recent_context.lower() for word in ["aile", "family", "kardeş", "anne", "baba"]):
                    if character_name == "Jon Snow":
                        responses = [
                            f"{character['emoji']} *Acıyla* Aile... *Duraksama* Ned Stark beni büyüttü ama... *Zorlanır* gerçek babam kimdi bilmiyorum. *Ghost'a bakar* Ama Stark'lar benim ailem. Robb, Sansa, Arya, Bran... *Kararlı* Onları korumak için her şeyi yaparım.",
                            f"{character['emoji']} *Ateşin başında oturur* Aile karmaşık bir şey. *Düşünceli* Bastard olarak büyüdüm, ama Catelyn Lady haricinde herkes beni kabul etti. *Winterfell'i hatırlar* Şimdi onları korumaya çalışıyorum, her ne pahasına olursa olsun."
                        ]
                    elif character_name == "Tyrion Lannister":
                        responses = [
                            f"{character['emoji']} *Şarap kadehini sıkıca tutar* Aile mı? *Acı gülümseme* Babam benden nefret ediyor, kız kardeşim beni öldürmek istiyor, ağabeyim... *duraksama* o en azından umursuyor. *Şaraptan yudum* Lannister ailesi, altın gibi parlak ama soğuk.",
                            f"{character['emoji']} *Kitabını kapatır* Ailem bana 'canavar' der. *İronik* Ama asıl canavar kim, belli değil. *Düşünceli* Belki de aile, kan bağından çok, sevgiden ibaret olmalı."
                        ]
                    else:
                        responses = [
                            f"{character['emoji']} *{character['personality']} ifadeyle* Aile... *Uzağa bakar* Bu savaşlarda çok aileyi kaybettik. *{character['speaking_style']} sesle* Ama kan bağları güçlüdür, sevgi daha da güçlü. Senin ailen nasıl?",
                            f"{character['emoji']} *Sıcak bir gülümseme* {random.choice(character['quotes'])} *Duraksama* Aile, insanın en büyük gücü... ve bazen en büyük zaafı da olabilir."
                        ]
                else:
                    # Konuşma bağlamına göre genel cevaplar
                    responses = [
                        f"{character['emoji']} *{character['personality']} tavırla dinliyor* {random.choice(character['quotes'])} *Düşünceli* Anlıyorum ne demek istediğini. Bu topraklarda herkesin bir hikayesi var.",
                        f"{character['emoji']} *{character['speaking_style']} sesle* İlginç bir konu bu. *Etrafı gözlemler* Westeros'ta her gün yeni bir şey öğreniyoruz. Sen ne düşünüyorsun bu konuda?",
                        f"{character['emoji']} *{character['personality']} bir ifadeyle* Haklısın dostum. *Duraksama* Bazen konuşmak, savaşmaktan daha zordur ama daha faydalı."
                    ]
            else:
                # İlk tanışma veya genel durumlar için zengin cevaplar
                responses = [
                    f"{character['emoji']} *{character['speaking_style']} tavırla* {random.choice(character['quotes'])} *Sana odaklanır* Bu güzel bir sohbet başlangıcı. Daha fazla söylemek istediğin var mı?",
                    f"{character['emoji']} *{character['personality']} bir şekilde yaklaşır* Westeros'ta ilginç zamanlar yaşıyoruz gerçekten. *Etrafı gözden geçirir* Her gün yeni haberler, yeni ittifaklar, yeni düşmanlar... Sen nasıl başa çıkıyorsun bu karmaşayla?",
                    f"{character['emoji']} *Düşünceli bir sessizlik* Bilirsin, bu topraklarda herkesin bir amacı var. *Sana bakar* Seninki nedir merak ediyorum?"
                ]
        
        return random.choice(responses)
    
    async def start_rp_session(self, guild_id: int, channel_id: int, character_name: Optional[str] = None):
        """RP oturumu başlat"""
        if not character_name:
            character_name = self.get_random_character()
        
        self.active_rp_sessions[guild_id] = {
            "character": character_name,
            "channel_id": channel_id,
            "start_time": datetime.now(),
            "message_count": 0
        }
        
        # Sohbet geçmişini başlat
        if guild_id not in self.conversation_history:
            self.conversation_history[guild_id] = []
        
        logger.info(f"RP session started in guild {guild_id} with character {character_name}")
        return character_name
    
    async def end_rp_session(self, guild_id: int):
        """RP oturumunu sonlandır"""
        if guild_id in self.active_rp_sessions:
            session = self.active_rp_sessions.pop(guild_id)
            # Sohbet geçmişini temizle (isteğe bağlı - hafızayı korumak için yoruma alınabilir)
            # if guild_id in self.conversation_history:
            #     del self.conversation_history[guild_id]
            logger.info(f"RP session ended in guild {guild_id} with character {session['character']}")
            return session
        return None
    
    def get_active_session(self, guild_id: int):
        """Aktif RP oturumu bilgisi al"""
        return self.active_rp_sessions.get(guild_id)
    
    async def process_rp_message(self, message):
        """RP mesajını işle ve cevap ver - konuşmayı hafızaya kaydeder"""
        guild_id = message.guild.id
        session = self.get_active_session(guild_id)
        
        if not session:
            return None
        
        # Kullanıcı mesajını geçmişe ekle
        if guild_id not in self.conversation_history:
            self.conversation_history[guild_id] = []
        
        self.conversation_history[guild_id].append({
            "author": message.author.display_name,
            "content": message.content,
            "timestamp": datetime.now(),
            "type": "user"
        })
        
        # Son 10 mesajı tut (dengeli hafıza)
        if len(self.conversation_history[guild_id]) > 10:
            self.conversation_history[guild_id] = self.conversation_history[guild_id][-10:]
        
        # Mesaj sayısını artır
        session["message_count"] += 1
        
        # Cevap oluştur (ittifak bilgileri ile gelişmiş sistem)
        character_name = session["character"]
        response = self.generate_enhanced_rp_response(character_name, message.content, message.author.id, guild_id)
        
        # Bot cevabını da geçmişe ekle
        self.conversation_history[guild_id].append({
            "author": character_name,
            "content": response,
            "timestamp": datetime.now(),
            "type": "bot"
        })
        
        # Embed oluştur
        character = self.characters[character_name]
        embed = create_embed(
            title=f"{character['emoji']} {character_name}",
            description=response,
            color=discord.Color.gold()
        )
        # Kullanıcı ittifak bilgisini footer'a ekle
        alliance_info = self.get_user_alliance_info(message.author.id)
        footer_text = f"RP Modu • {character['personality']} • Mesaj #{session['message_count']}"
        if alliance_info:
            footer_text += f" • {alliance_info['alliance_name']} ({alliance_info['role']})"
        
        embed.set_footer(text=footer_text)
        
        return embed
    
    def get_user_alliance_info(self, user_id):
        """Kullanıcının ittifak bilgilerini al"""
        try:
            # Güvenli veritabanı bağlantısı
            if not hasattr(self.db, 'conn') or self.db.conn is None:
                logger.error("Database connection not available")
                return None
                
            cursor = self.db.conn.cursor()
            cursor.execute('''
                SELECT a.name, a.gold, a.soldiers, a.power_points, m.role, m.level, m.experience
                FROM members m
                JOIN alliances a ON m.alliance_id = a.id
                WHERE m.user_id = ?
            ''', (user_id,))
            result = cursor.fetchone()
            cursor.close()
            
            if result:
                return {
                    'alliance_name': result[0],
                    'gold': result[1],
                    'soldiers': result[2],
                    'power_points': result[3],
                    'role': result[4],
                    'level': result[5],
                    'experience': result[6]
                }
            return None
        except Exception as e:
            logger.error(f"Error getting user alliance info: {e}")
            return None
    
    def get_alliance_wars(self, alliance_name):
        """İttifakın savaş durumunu al"""
        try:
            # Güvenli veritabanı bağlantısı
            if not hasattr(self.db, 'conn') or self.db.conn is None:
                logger.error("Database connection not available")
                return []
                
            cursor = self.db.conn.cursor()
            cursor.execute('''
                SELECT attacker_alliance, defender_alliance, status, created_at
                FROM wars 
                WHERE (attacker_alliance = ? OR defender_alliance = ?) 
                AND status = 'active'
                ORDER BY created_at DESC LIMIT 3
            ''', (alliance_name, alliance_name))
            result = cursor.fetchall()
            cursor.close()
            return result
        except Exception as e:
            logger.error(f"Error getting alliance wars: {e}")
            return []
    
    def generate_enhanced_rp_response(self, character_name: str, user_message: str, user_id: int, guild_id: Optional[int] = None) -> str:
        """İttifak bilgilerini de içeren gelişmiş RP cevabı"""
        character = self.characters[character_name]
        
        # Kullanıcının ittifak bilgilerini al
        alliance_info = self.get_user_alliance_info(user_id)
        user_msg_lower = user_message.lower()
        
        # İttifak ve savaş konularında özel cevaplar
        if any(word in user_msg_lower for word in ["ittifak", "alliance", "savaş", "war", "altın", "gold", "asker", "soldier"]):
            if alliance_info:
                alliance_name = alliance_info['alliance_name']
                wars = self.get_alliance_wars(alliance_name)
                
                if character_name == "Tyrion Lannister":
                    if wars:
                        responses = [
                            f"{character['emoji']} *Şarap kadehini çevirerek düşünceli* {alliance_name} ittifakından mısın? *Zeki gözlerle* İlginç... Savaş durumunda olduğunuzu duydum. *Stratejik bakış* Bilirsin, savaş sadece kılıçla kazanılmaz, diplomasi ve zeka gerekir. {alliance_info['gold']} altının var, akıllıca kullan.",
                            f"{character['emoji']} *Kitabından başını kaldırır* Ah, {alliance_name}... *İronik gülümseme* Politik manzara her zaman ilginçtir. {wars[0][0]} ve {wars[0][1]} arasındaki savaşı takip ediyorum. *Şaraptan yudum* Hangi tarafta yer alıyorsun? Tabii eğer akıllıysan, kazanan tarafta..."
                        ]
                    else:
                        responses = [
                            f"{character['emoji']} *Hesap kitap yapar* {alliance_name} ittifakı ha? {alliance_info['gold']} altın, {alliance_info['soldiers']} asker... *Onaylayarak başını sallar* İyi bir ekonomik durum. Barış zamanında hazırlık yapmak, akıllı liderlerin işidir. Bir Lannister olarak takdir ederim.",
                            f"{character['emoji']} *Şarap şişesini işaret eder* Gel, seninle {alliance_name} ittifakının geleceğini konuşalım. *Diplomatik tavır* {alliance_info['level']}. seviye, deneyimli görünüyorsun. Belki birlikte iş yapabiliriz?"
                        ]
                elif character_name == "Jon Snow":
                    if wars:
                        responses = [
                            f"{character['emoji']} *Longclaw'a dokunur* {alliance_name}... savaş zamanlarında zorlu kararlar almak gerekir. *Ciddi bakış* {wars[0][0]} ile {wars[0][1]} arasındaki çatışmayı biliyorum. Stark adaleti der ki: doğru olan tarafta yer al, kolay olan tarafta değil.",
                            f"{character['emoji']} *Ghost'un yanında durur* Savaş... her zaman kayıplar getirir. *Düşünceli* {alliance_info['soldiers']} askerin var, onları koruma sorumluluğun büyük. Kuzey'de öğrendim: liderlik, insanları ölüme göndermek değil, onları yaşatmaktır."
                        ]
                    else:
                        responses = [
                            f"{character['emoji']} *Karla kaplı pelerini düzeltir* {alliance_name} ittifakından... Barış zamanları hazırlık zamanıdır. *Kış geliyor uyarısı* Altının ({alliance_info['gold']}) yeterli, ama gıda stokladınız mı? Kış uzun olacak.",
                            f"{character['emoji']} *Ateşin başında oturur* {alliance_info['role']} rolündeki sorumluluklarını ciddiye alıyorsun umarım. *Stark onuru* Bir lider, halkının refahından sorumludur. Ne planlıyorsun gelecek için?"
                        ]
                elif character_name == "Daenerys Targaryen":
                    responses = [
                        f"{character['emoji']} *Ejder gözlerle* {alliance_name}... *Güçlü duruş* Adalet için mi savaşıyorsun, yoksa sadece güç için mi? *Kraliçe tavrı* {alliance_info['power_points']} güç puanın var, ama gerçek güç halkını korumaktan gelir. Zincirler kırılmalı, zalimler cezalandırılmalı.",
                        f"{character['emoji']} *Ejderlerinin yanında* Sen de bir lider misin? *Otorite* {alliance_info['level']} seviye, deneyim kazanmışsın. Ama unutma: kraliçe olmak kolay, adil kraliçe olmak zor. Halkın seni neden takip ediyor?"
                    ]
                else:
                    responses = [
                        f"{character['emoji']} *{character['personality']} tavırla* {alliance_name} ha... *Değerlendirici bakış* {alliance_info['gold']} altın ile güzel bir başlangıç. Bu topraklarda ittifaklar her şeydir. *{character['speaking_style']} sesle* Dostların kimler, düşmanların kimler?",
                        f"{character['emoji']} *Savaş deneyimi ile* {alliance_info['soldiers']} asker... respectable bir güç. *Onaylar* Ama unutma, en iyi savaşçı savaşmadan kazanan savaşçıdır."
                    ]
            else:
                # Ittifaksız kullanıcıya tavsiye
                if character_name == "Tyrion Lannister":
                    responses = [
                        f"{character['emoji']} *Şarap kadehinden yudum alır* Ittifaksız mısın? *Şaşkın* Bu Westeros'ta oldukça tehlikeli. *Akıl verir* Bir ittifaka katıl, ya da kendi ittifakını kur. Tek başına bu oyunu kazanamazsın.",
                        f"{character['emoji']} *Kitap kapatır* Akıllı insanlar güçlü ittifaklara katılır. *İroni* Tabii eğer akıllıysan... Sen ne bekliyorsun? Git !ittifak_kur komutu ile kendi haneni kur!"
                    ]
                else:
                    responses = [
                        f"{character['emoji']} *{character['personality']} tavırla* Bu topraklarda yalnız kalırsan kaybolursun. *Tavsiye verir* Bir ittifak bul, güvenilir dostlar edin. {character_name} olarak sana tavsiyem bu."
                    ]
            
            return random.choice(responses)
        
        # Normal RP cevapları (eski sistem devam eder)
        return self.generate_rp_response(character_name, "", user_message, guild_id)

async def setup_rp_commands(bot, db, rp_system):
    """RP komutlarını ayarla"""
    
    @bot.command(name='rp_start', help='Bot ile RP oturumu başlatır')
    async def rp_start(ctx, character_name: Optional[str] = None):
        """RP oturumu başlat"""
        
        # Mevcut oturum kontrolü
        if rp_system.get_active_session(ctx.guild.id):
            embed = create_embed(
                title="❌ Hata",
                description="Bu sunucuda zaten aktif bir RP oturumu var. Önce `!rp_stop` ile durdurun.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        # Karakter doğrulama
        if character_name and character_name not in rp_system.characters:
            available_chars = ", ".join(rp_system.characters.keys())
            embed = create_embed(
                title="❌ Geçersiz Karakter",
                description=f"Mevcut karakterler:\n{available_chars}",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        # Oturum başlat
        selected_character = await rp_system.start_rp_session(ctx.guild.id, ctx.channel.id, character_name)
        character_data = rp_system.characters[selected_character]
        
        embed = create_embed(
            title="🎭 RP Oturumu Başladı!",
            description=f"**{character_data['emoji']} {selected_character}** artık bu kanalda rol yapıyor!\n\n"
                       f"**Kişilik:** {character_data['personality']}\n"
                       f"**Konuşma Tarzı:** {character_data['speaking_style']}\n\n"
                       f"*{random.choice(character_data['quotes'])}*",
            color=discord.Color.gold()
        )
        embed.set_footer(text="RP'yi durdurmak için !rp_stop kullanın")
        
        await ctx.send(embed=embed)
    
    @bot.command(name='rp_stop', help='RP oturumunu durdurur')
    async def rp_stop(ctx):
        """RP oturumunu durdur"""
        
        session = await rp_system.end_rp_session(ctx.guild.id)
        if not session:
            embed = create_embed(
                title="❌ Hata",
                description="Bu sunucuda aktif RP oturumu yok.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        duration = datetime.now() - session['start_time']
        minutes = int(duration.total_seconds() // 60)
        
        embed = create_embed(
            title="🎭 RP Oturumu Sona Erdi",
            description=f"**{session['character']}** ile olan RP oturumu sona erdi.\n\n"
                       f"**Süre:** {minutes} dakika\n"
                       f"**Mesaj Sayısı:** {session['message_count']}",
            color=discord.Color.blue()
        )
        
        await ctx.send(embed=embed)
    
    @bot.command(name='rp_status', help='Aktif RP oturum bilgisini gösterir')
    async def rp_status(ctx):
        """RP oturum durumunu göster"""
        
        session = rp_system.get_active_session(ctx.guild.id)
        if not session:
            embed = create_embed(
                title="📊 RP Durum",
                description="Bu sunucuda aktif RP oturumu yok.\n\n`!rp_start` ile yeni oturum başlatabilirsiniz.",
                color=discord.Color.blue()
            )
            await ctx.send(embed=embed)
            return
        
        character_data = rp_system.characters[session['character']]
        duration = datetime.now() - session['start_time']
        minutes = int(duration.total_seconds() // 60)
        
        embed = create_embed(
            title=f"📊 Aktif RP Oturumu",
            description=f"**Karakter:** {character_data['emoji']} {session['character']}\n"
                       f"**Süre:** {minutes} dakika\n"
                       f"**Mesaj Sayısı:** {session['message_count']}\n"
                       f"**Kanal:** <#{session['channel_id']}>\n\n"
                       f"**Kişilik:** {character_data['personality']}",
            color=discord.Color.gold()
        )
        
        await ctx.send(embed=embed)
    
    @bot.command(name='rp_characters', help='Mevcut RP karakterlerini listeler')
    async def rp_characters(ctx):
        """Mevcut karakterleri listele"""
        
        embed = create_embed(
            title="🎭 Mevcut RP Karakterleri",
            description="Bot olarak canlandırabileceğim karakterler:",
            color=discord.Color.gold()
        )
        
        for name, data in rp_system.characters.items():
            embed.add_field(
                name=f"{data['emoji']} {name}",
                value=f"**Kişilik:** {data['personality']}\n**Tarz:** {data['speaking_style']}",
                inline=False
            )
        
        embed.set_footer(text="!rp_start [karakter_adı] ile RP başlatın")
        await ctx.send(embed=embed)
    
    @bot.command(name='rp_history', help='RP sohbet geçmişini gösterir')
    async def rp_history(ctx, limit: int = 10):
        """RP sohbet geçmişini göster"""
        
        guild_id = ctx.guild.id
        if guild_id not in rp_system.conversation_history:
            embed = create_embed(
                title="📜 Sohbet Geçmişi",
                description="Bu sunucuda henüz RP sohbet geçmişi yok.",
                color=discord.Color.blue()
            )
            await ctx.send(embed=embed)
            return
        
        history = rp_system.conversation_history[guild_id]
        if not history:
            embed = create_embed(
                title="📜 Sohbet Geçmişi",
                description="Sohbet geçmişi boş.",
                color=discord.Color.blue()
            )
            await ctx.send(embed=embed)
            return
        
        # Son N mesajı al
        recent_messages = history[-limit:] if len(history) > limit else history
        
        embed = create_embed(
            title="📜 RP Sohbet Geçmişi",
            description=f"Son {len(recent_messages)} mesaj:",
            color=discord.Color.gold()
        )
        
        for msg in recent_messages:
            timestamp = msg['timestamp'].strftime("%H:%M")
            author_icon = "🤖" if msg['type'] == 'bot' else "👤"
            embed.add_field(
                name=f"{author_icon} {msg['author']} - {timestamp}",
                value=msg['content'][:100] + ("..." if len(msg['content']) > 100 else ""),
                inline=False
            )
        
        embed.set_footer(text=f"Toplam mesaj: {len(history)} | Gösterilen: {len(recent_messages)}")
        await ctx.send(embed=embed)
    
    @bot.command(name='rp_clear_history', help='RP sohbet geçmişini temizler')
    @commands.has_permissions(manage_messages=True)
    async def rp_clear_history(ctx):
        """RP sohbet geçmişini temizle (sadece moderatörler)"""
        
        guild_id = ctx.guild.id
        if guild_id in rp_system.conversation_history:
            del rp_system.conversation_history[guild_id]
            
        embed = create_embed(
            title="🗑️ Geçmiş Temizlendi",
            description="RP sohbet geçmişi başarıyla temizlendi.",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)
    
    # Otomatik RP tetiklenmesi için mesaj dinleyicisi
    @bot.event
    async def on_message_rp(message):
        """Mesajları dinle ve RP tetiklenmesini kontrol et"""
        
        # Bot mesajlarını ignore et
        if message.author.bot:
            return
        
        # Aktif RP oturumu var mı?
        session = rp_system.get_active_session(message.guild.id)
        if not session:
            return
        
        # RP kanalında mı?
        if message.channel.id != session['channel_id']:
            return
        
        # Bot mention edilmiş mi veya RP tetiklenmeli mi?
        bot_mentioned = bot.user in message.mentions
        should_respond = rp_system.should_respond_to_rp(message.content)
        
        # %15 şans ile rastgele cevap ver (çok spam olmasın)
        random_response = random.random() < 0.15
        
        if bot_mentioned or should_respond or random_response:
            # Yazıyor göstergesi
            async with message.channel.typing():
                await asyncio.sleep(random.uniform(1, 3))  # Gerçekçi bekleme
                
                embed = await rp_system.process_rp_message(message)
                if embed:
                    await message.channel.send(embed=embed)
    
    # Mevcut on_message event'ini extend et
    original_on_message = bot.get_cog('on_message') or bot.event
    
    @bot.event
    async def on_message(message):
        # Önce RP kontrolü
        await on_message_rp(message)
        
        # Sonra normal komut işleme
        await bot.process_commands(message)
    
    @bot.command(name="rp_alliance_status", help="İttifakın durumunu RP karakteri ile öğren")
    async def rp_alliance_status(ctx):
        """İttifak durumunu RP karakteri ile öğren"""
        guild_id = ctx.guild.id
        user_id = ctx.author.id
        
        # Aktif RP oturumu kontrol et
        if guild_id not in rp_system.active_rp_sessions:
            embed = discord.Embed(
                title="❌ RP Oturumu Yok",
                description="Önce `!rp_start [karakter_adı]` ile RP oturumu başlatın!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        session = rp_system.active_rp_sessions[guild_id]
        character_name = session["character"]
        character = rp_system.characters[character_name]
        
        # Kullanıcı ittifak bilgilerini al
        alliance_info = rp_system.get_user_alliance_info(user_id)
        
        if not alliance_info:
            response = f"{character['emoji']} *{character['personality']} tavırla* Sen bir ittifaka dahil değilsin. *Tavsiye verir* Bu Westeros'ta çok tehlikeli! Hemen bir ittifak kur veya katıl. Yalnızlık burada ölüm demektir."
        else:
            alliance_name = alliance_info['alliance_name']
            wars = rp_system.get_alliance_wars(alliance_name)
            
            if character_name == "Tyrion Lannister":
                response = f"{character['emoji']} *Hesap kitap yaparken* {alliance_name} ittifakının durumu:\n"
                response += f"💰 **Altın:** {alliance_info['gold']:,}\n"
                response += f"⚔️ **Asker:** {alliance_info['soldiers']:,}\n" 
                response += f"🔥 **Güç:** {alliance_info['power_points']:,}\n"
                response += f"👑 **Senin Rolün:** {alliance_info['role']} (Seviye {alliance_info['level']})\n\n"
                if wars:
                    response += f"*Şaraptan yudum* Ah, ve savaş durumundasınız! {wars[0][0]} vs {wars[0][1]} çatışması devam ediyor. *Stratejik düşünür* Diplomasi her zaman daha iyi sonuç verir..."
                else:
                    response += f"*Onaylar* Barış zamanında güçlü durumdaysınız. Akıllı liderlik!"
            elif character_name == "Jon Snow":
                response = f"{character['emoji']} *Ciddi bakış* {alliance_name} ittifakının sorumluluğu büyük:\n"
                response += f"⚔️ **{alliance_info['soldiers']:,} asker** bekliyor emrini\n"
                response += f"💰 **{alliance_info['gold']:,} altın** ile geçimlerini sağlıyorsun\n"
                response += f"🔥 **{alliance_info['power_points']:,} güç** puanın var\n\n"
                if wars:
                    response += f"*Longclaw'a dokunur* Savaş zamanında liderlik zor. Askerlerin güvende olduğundan emin ol."
                else:
                    response += f"*Stark adaleti* Barış zamanında hazırlık yap. Kış geliyor, her zaman."
            else:
                response = f"{character['emoji']} **{alliance_name} İttifakı**\n\n"
                response += f"💰 Altın: {alliance_info['gold']:,}\n⚔️ Asker: {alliance_info['soldiers']:,}\n🔥 Güç: {alliance_info['power_points']:,}\n👑 Rolün: {alliance_info['role']}"
                if wars:
                    response += f"\n\n⚔️ **Aktif savaşlar var!** Dikkatli ol."
        
        embed = discord.Embed(
            title=f"{character['emoji']} {character_name}",
            description=response,
            color=discord.Color.gold()
        )
        await ctx.send(embed=embed)
    
    @bot.command(name="rp_negotiate", help="İttifaklar arası müzakere başlat (RP)")
    async def rp_negotiate(ctx, *, target_alliance: str = None):
        """İttifaklar arası RP müzakeresi"""
        if not target_alliance:
            embed = discord.Embed(
                title="❌ Eksik Bilgi",
                description="Kullanım: `!rp_negotiate [hedef_ittifak]`",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        guild_id = ctx.guild.id
        user_id = ctx.author.id
        
        # Aktif RP oturumu kontrol et
        if guild_id not in rp_system.active_rp_sessions:
            embed = discord.Embed(
                title="❌ RP Oturumu Yok",
                description="Önce `!rp_start [karakter_adı]` ile RP oturumu başlatın!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        session = rp_system.active_rp_sessions[guild_id]
        character_name = session["character"]
        character = rp_system.characters[character_name]
        
        # Kullanıcı ittifak bilgilerini al
        alliance_info = rp_system.get_user_alliance_info(user_id)
        
        if not alliance_info:
            response = f"{character['emoji']} *{character['personality']} ile* Sen bir ittifakta değilsin ki! Nasıl müzakere yapacaksın? *Şaşkın* Önce bir ittifak kur!"
        else:
            user_alliance = alliance_info['alliance_name']
            
            if character_name == "Tyrion Lannister":
                response = f"{character['emoji']} *Şarap kadehini kaldırır* Ah, diplomasi! En sevdiğim oyun. *Zeki gülümseme* {user_alliance} adına {target_alliance} ile müzakere mi?\n\n"
                response += f"*Stratejik düşünür* İyi bir anlaşma her iki tarafın da kazandığı anlaşmadır. Ne teklif edeceksin?\n\n"
                response += f"**Müzakere seçenekleri:**\n🤝 Barış anlaşması\n💰 Ticaret antlaşması\n⚔️ Askeri ittifak\n🏰 Bölge paylaşımı"
            elif character_name == "Jon Snow":
                response = f"{character['emoji']} *Ciddi bakış* Müzakere... Stark'lar her zaman sözünün eri oldu. *Dürüst* {user_alliance} ile {target_alliance} arasında adaletli bir anlaşma yapabiliriz.\n\n"
                response += f"*Kuzey bilgisi* Doğru anlaşmalar, uzun barışlar getirir. Ne istiyorsun onlardan?"
            elif character_name == "Daenerys Targaryen":
                response = f"{character['emoji']} *Kraliçe otoritesi* {target_alliance} ile mi? *Güçlü duruş* Ejder kraliçesi olarak adalet için müzakere yaparım.\n\n"
                response += f"*Kararlı* Eğer zalim değillerse, anlaşabiliriz. Ama unutma: zincirler kırılacak!"
            else:
                response = f"{character['emoji']} *{character['personality']} tavırla* {user_alliance} ve {target_alliance} arasında müzakere başlatıyorum. Hangi konuda anlaşmak istiyorsun?"
            
            # Müzakere başlat
            rp_system.active_negotiations[guild_id] = {
                'user_alliance': user_alliance,
                'target_alliance': target_alliance,
                'character': character_name,
                'started_by': user_id,
                'timestamp': discord.utils.utcnow()
            }
        
        embed = discord.Embed(
            title=f"{character['emoji']} {character_name}",
            description=response,
            color=discord.Color.gold()
        )
        await ctx.send(embed=embed)
    
    @bot.command(name="rp_war_council", help="Savaş meclisi topla (RP)")
    async def rp_war_council(ctx):
        """Savaş meclisi RP oturumu"""
        guild_id = ctx.guild.id
        user_id = ctx.author.id
        
        # Aktif RP oturumu kontrol et
        if guild_id not in rp_system.active_rp_sessions:
            embed = discord.Embed(
                title="❌ RP Oturumu Yok", 
                description="Önce `!rp_start [karakter_adı]` ile RP oturumu başlatın!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        session = rp_system.active_rp_sessions[guild_id]
        character_name = session["character"]
        character = rp_system.characters[character_name]
        
        # Kullanıcı ittifak bilgilerini al
        alliance_info = rp_system.get_user_alliance_info(user_id)
        
        if not alliance_info:
            response = f"{character['emoji']} *{character['personality']} ile* Savaş meclisi için bir ittifakta olman gerek! *Ciddi* Yalnız başına savaş planı yapamazsın."
        else:
            alliance_name = alliance_info['alliance_name']
            wars = rp_system.get_alliance_wars(alliance_name)
            
            if character_name == "Tyrion Lannister":
                response = f"{character['emoji']} *Harita masasının başında* {alliance_name} savaş meclisi toplanıyor! *Stratejik* \n\n"
                response += f"**Mevcut Durum:**\n💰 Altın: {alliance_info['gold']:,}\n⚔️ Asker: {alliance_info['soldiers']:,}\n🔥 Güç: {alliance_info['power_points']:,}\n\n"
                if wars:
                    response += f"*Ciddi bakış* {wars[0][0]} vs {wars[0][1]} savaşında yer alıyoruz. *Zeka* Stratejimizi gözden geçirmeliyiz!\n\n"
                    response += f"**Savaş Seçenekleri:**\n🏰 Savunma pozisyonu\n⚔️ Saldırı planı\n🛡️ Diplomatik çözüm\n💰 Paralı asker kirala"
                else:
                    response += f"*Önleyici düşünür* Şu an barıştayız, ama hazırlık gerek. Hangi ittifakla sorunumuz olabilir?\n\n"
                    response += f"**Hazırlık Seçenekleri:**\n🏗️ Savunma güçlendir\n👥 Asker eğit\n🤝 Müttefik ara\n📍 Strateji belirle"
            elif character_name == "Jon Snow":
                response = f"{character['emoji']} *Longclaw'ı masaya koyar* {alliance_name} savaşçıları! *Liderlik* Stark onuru ile savaşacağız.\n\n"
                if wars:
                    response += f"*Kararlı* Savaştayız. Ama unutmayın: savaşın amacı barış getirmektir. {alliance_info['soldiers']} askerin hayatı benim sorumluluğum.\n\n"
                    response += f"**Kuzey Taktiği:**\n❄️ Kış avantajı kullan\n🐺 Direwolf stratejisi\n🛡️ Kalkan duvarı\n⚔️ Kararlı saldırı"
                else:
                    response += f"*Kuzey bilgisi* Barış zamanında savaşa hazırlan. Kış geliyor, her zaman. {alliance_info['soldiers']} askerimiz eğitime devam etmeli.\n\n" 
                    response += f"**Kuzey Hazırlığı:**\n🥶 Kış malzemesi\n🏹 Silah bakımı\n👨‍🏫 Eğitim kampı\n🏰 Kale güçlendir"
            else:
                response = f"{character['emoji']} **{alliance_name} Savaş Meclisi**\n\n*{character['personality']} ile konuşur*\n\n"
                response += f"Mevcut gücümüz: {alliance_info['soldiers']:,} asker, {alliance_info['gold']:,} altın\n\n"
                if wars:
                    response += f"**Aktif savaş var!** Plan yapmamız gerek."
                else:
                    response += f"Barış zamanında güçlenmeliyiz."
        
        embed = discord.Embed(
            title=f"⚔️ {character_name} - Savaş Meclisi",
            description=response,
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)

    logger.info("RP System commands loaded successfully")
#!/usr/bin/env python3
import os
import threading
import time
import signal
import sys
from flask import Flask, jsonify
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)

# App status
app_status = {
    'flask_running': True,
    'bot_running': False,
    'bot_last_start': None,
    'bot_error': None,
    'start_time': time.time()
}

@app.route('/')
def home():
    return f"""
    <html>
    <head>
        <title>🏰 Iron Throne RP Bot</title>
        <meta http-equiv="refresh" content="30">
    </head>
    <body style="font-family: Arial; background: #2c2f33; color: #ffffff; text-align: center; padding: 50px;">
        <h1>🏰 Game of Thrones Discord Bot</h1>
        <h2>⚔️ Iron Throne RP - Demir Taht Roleplay</h2>
        <div style="background: #23272a; padding: 20px; margin: 20px; border-radius: 10px;">
            <h3>📊 System Status</h3>
            <p>🌐 Flask Server: <span style="color: #43b581;">✅ Running</span></p>
            <p>🤖 Discord Bot: <span style="color: {'#43b581' if app_status['bot_running'] else '#f04747'}">{'✅ Active' if app_status['bot_running'] else '⏳ Starting'}</span></p>
            <p>⏱️ Uptime: {int((time.time() - app_status['start_time']) / 60)} minutes</p>
        </div>
        <p>🏆 167+ Commands | 🏰 10 Houses | ⚔️ Advanced War System</p>
        <p>💰 Economy System | 👑 Marriage System | 🛡️ Auto Moderation</p>
        <hr>
        <p><a href="/status" style="color: #7289da;">Detailed Status</a> | <a href="/health" style="color: #7289da;">Health Check</a></p>
        <p><small>Created by xxkaan44xx | Running 24/7 on Replit</small></p>
    </body>
    </html>
    """

@app.route('/status')
def status():
    return jsonify({
        "service": "Iron Throne RP Discord Bot",
        "version": "3.0 Professional Edition",
        "flask_server": "running",
        "bot_status": "active" if app_status['bot_running'] else "starting",
        "bot_last_start": app_status['bot_last_start'],
        "bot_error": app_status['bot_error'],
        "uptime_seconds": int(time.time() - app_status['start_time']),
        "commands": "167+",
        "systems": ["War", "Economy", "Marriage", "Tournament", "Trade", "RP", "Auto-Moderation"],
        "port": 5000,
        "timestamp": time.time()
    })

@app.route('/health')
def health():
    return jsonify({
        "status": "healthy",
        "flask": "running",
        "bot": "active" if app_status['bot_running'] else "starting",
        "port": 5000,
        "uptime": int(time.time() - app_status['start_time']),
        "last_check": time.time()
    }), 200

def start_bot():
    """Start the Discord bot"""
    try:
        logger.info("Initializing Discord bot...")
        app_status['bot_last_start'] = time.time()
        
        # Import the main function and run it
        from main import main
        import asyncio
        
        # Run the bot
        asyncio.run(main())
        
    except Exception as e:
        error_msg = f"Bot startup error: {e}"
        logger.error(error_msg)
        app_status['bot_error'] = str(e)
        app_status['bot_running'] = False
        # Don't restart automatically to prevent infinite loops
        
def signal_handler(signum, frame):
    """Handle shutdown signals"""
    logger.info("Shutdown signal received")
    app_status['bot_running'] = False
    sys.exit(0)

if __name__ == '__main__':
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logger.info("🏰 Starting Iron Throne RP Bot System...")
    
    # Start Discord bot in background thread
    logger.info("Starting Discord bot in background thread...")
    bot_thread = threading.Thread(target=start_bot, daemon=True)
    bot_thread.start()
    
    # Give the bot a moment to start
    time.sleep(1)
    app_status['bot_running'] = True
    
    # Start Flask server on main thread
    port = int(os.environ.get('PORT', 5000))
    logger.info(f"Starting Flask web server on 0.0.0.0:{port}")
    
    try:
        # Run Flask with proper configuration
        app.run(
            host='0.0.0.0',
            port=port,
            debug=False,
            threaded=True,
            use_reloader=False
        )
    except Exception as e:
        logger.error(f"Flask server error: {e}")
        # Emergency fallback - keep process alive
        logger.info("Flask failed, entering fallback mode...")
        try:
            while True:
                logger.info(f"Fallback mode active - Bot: {app_status['bot_running']}")
                time.sleep(60)
        except KeyboardInterrupt:
            logger.info("Process terminated")
            sys.exit(0)
#!/usr/bin/env python3
"""
Script to update army data for all Game of Thrones houses
Updates both alliance table (basic stats) and army_resources table (detailed equipment)
"""

import sqlite3
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def update_house_armies():
    """Update army data for all houses"""
    
    # Connect to database
    conn = sqlite3.connect('got_rp.db')
    c = conn.cursor()
    
    # Army data for each house
    houses_data = {
        # Iron Throne (King's Landing)
        'Iron Throne': {
            'soldiers': 10000,
            'armor_percentage': 60,
            'knight_percentage': 10,
            'crossbows': 3500,
            'catapults': 15,
            'siege_towers': 15,
            'scorpions': 30,
            'ballistas': 8,
            'swords': 10000,
            'shields': 10000,
            'dried_meat_months': 5,
            'beer_months': 5,
            'grain_months': 6,
            'steel_quality': 'high',
            'steel_equipment': 3000,
            'big_ships': 3,
            'medium_ships': 4,
            'fast_ships': 4,
            'long_ships': 2,
            'special': 'Capital logistics, elite command'
        },
        
        # House Stark
        'Stark': {
            'soldiers': 20000,
            'armor_percentage': 30,
            'knight_percentage': 1,
            'crossbows': 1500,
            'catapults': 15,
            'siege_towers': 5,
            'scorpions': 20,
            'ballistas': 4,
            'swords': 25000,
            'shields': 20000,
            'dried_meat_months': 4,
            'beer_months': 1,
            'grain_months': 7,
            'steel_quality': 'medium',
            'steel_equipment': 5000,
            'big_ships': 0,
            'medium_ships': 0,
            'fast_ships': 0,
            'long_ships': 0,
            'special': 'Loyalty, harsh climate discipline'
        },
        
        # House Lannister
        'Lannister': {
            'soldiers': 60000,
            'armor_percentage': 90,
            'knight_percentage': 12,
            'crossbows': 8000,
            'catapults': 50,
            'siege_towers': 45,
            'scorpions': 60,
            'ballistas': 30,
            'swords': 75000,
            'shields': 65000,
            'dried_meat_months': 6,
            'beer_months': 6,
            'grain_months': 8,
            'steel_quality': 'very_high',
            'steel_equipment': 25000,
            'big_ships': 11,
            'medium_ships': 21,
            'fast_ships': 19,
            'long_ships': 9,
            'special': 'Wealth, elite cavalry, quality weapons'
        },
        
        # House Baratheon
        'Baratheon': {
            'soldiers': 35000,
            'armor_percentage': 65,
            'knight_percentage': 8,
            'crossbows': 3000,
            'catapults': 25,
            'siege_towers': 15,
            'scorpions': 40,
            'ballistas': 8,
            'swords': 40000,
            'shields': 35000,
            'dried_meat_months': 3,
            'beer_months': 2,
            'grain_months': 3,
            'steel_quality': 'medium_high',
            'steel_equipment': 10000,
            'big_ships': 10,
            'medium_ships': 60,
            'fast_ships': 60,
            'long_ships': 20,
            'special': 'Disciplined infantry, medium cavalry'
        },
        
        # House Tyrell
        'Tyrell': {
            'soldiers': 90000,
            'armor_percentage': 75,
            'knight_percentage': 20,
            'crossbows': 9000,
            'catapults': 40,
            'siege_towers': 30,
            'scorpions': 100,
            'ballistas': 30,
            'swords': 100000,
            'shields': 95000,
            'dried_meat_months': 12,
            'beer_months': 6,
            'grain_months': 12,
            'steel_quality': 'medium',
            'steel_equipment': 20000,
            'big_ships': 10,
            'medium_ships': 15,
            'fast_ships': 20,
            'long_ships': 10,
            'special': 'Large army, agricultural power, logistics superiority'
        },
        
        # House Greyjoy
        'Greyjoy': {
            'soldiers': 8000,
            'armor_percentage': 10,
            'knight_percentage': 0,
            'crossbows': 1000,
            'catapults': 5,
            'siege_towers': 0,
            'scorpions': 5,
            'ballistas': 2,
            'swords': 10000,
            'shields': 3000,
            'dried_meat_months': 2,
            'beer_months': 2,
            'grain_months': 3.5,
            'steel_quality': 'low',
            'steel_equipment': 1000,
            'big_ships': 5,
            'medium_ships': 15,
            'fast_ships': 152,
            'long_ships': 32,
            'special': 'Guerrilla and raids, fast naval force'
        },
        
        # House Arryn
        'Arryn': {
            'soldiers': 12000,
            'armor_percentage': 60,
            'knight_percentage': 9,
            'crossbows': 1500,
            'catapults': 12,
            'siege_towers': 4,
            'scorpions': 15,
            'ballistas': 5,
            'swords': 15000,
            'shields': 12000,
            'dried_meat_months': 3,
            'beer_months': 1.5,
            'grain_months': 3,
            'steel_quality': 'medium',
            'steel_equipment': 5000,
            'big_ships': 1,
            'medium_ships': 3,
            'fast_ships': 6,
            'long_ships': 3,
            'special': 'High defense, mountain terrain advantage'
        },
        
        # House Martell
        'Martell': {
            'soldiers': 20000,
            'armor_percentage': 12,
            'knight_percentage': 3,
            'crossbows': 3500,
            'catapults': 10,
            'siege_towers': 1,
            'scorpions': 20,
            'ballistas': 20,
            'swords': 25000,
            'shields': 15000,
            'dried_meat_months': 4,
            'beer_months': 2,
            'grain_months': 2,
            'steel_quality': 'medium',
            'steel_equipment': 5000,
            'big_ships': 1,
            'medium_ships': 2,
            'fast_ships': 4,
            'long_ships': 4,
            'special': 'Guerrilla, desert warfare adapted, defense king'
        }
    }
    
    try:
        # Get existing houses
        c.execute('SELECT id, name FROM alliances')
        existing_houses = {row[1]: row[0] for row in c.fetchall()}
        logger.info(f"Found {len(existing_houses)} existing houses: {list(existing_houses.keys())}")
        
        updated_houses = 0
        
        for house_name, data in houses_data.items():
            if house_name in existing_houses:
                house_id = existing_houses[house_name]
                logger.info(f"Updating {house_name} (ID: {house_id})")
                
                # Update basic alliance data
                c.execute('''
                    UPDATE alliances 
                    SET soldiers = ?, army_quality = ?, gold = gold + ?
                    WHERE id = ?
                ''', (data['soldiers'], 
                     min(100, data['armor_percentage'] + data['knight_percentage']), 
                     50000,  # Give some bonus gold
                     house_id))
                
                # Calculate army metrics
                armored_soldiers = int(data['soldiers'] * data['armor_percentage'] / 100)
                knights = int(data['soldiers'] * data['knight_percentage'] / 100)
                total_siege = data['catapults'] + data['siege_towers'] + data['scorpions'] + data['ballistas']
                total_ships = data['big_ships'] + data['medium_ships'] + data['fast_ships'] + data['long_ships']
                
                # Steel quality mapping
                steel_quality_map = {
                    'low': 30,
                    'medium': 60,
                    'medium_high': 75,
                    'high': 85,
                    'very_high': 95
                }
                
                weapons_quality = steel_quality_map.get(data['steel_quality'], 60)
                armor_quality = weapons_quality
                
                # Food supplies calculation (months * 30 days * soldiers * 2 food per day)
                total_food = int((data['dried_meat_months'] + data['beer_months'] + data['grain_months']) / 3 * 30 * data['soldiers'] * 2)
                
                # Update or insert army resources
                c.execute('SELECT id FROM army_resources WHERE house_id = ?', (house_id,))
                if c.fetchone():
                    # Update existing record
                    c.execute('''
                        UPDATE army_resources SET
                            food_supplies = ?, weapons_quality = ?, armor_quality = ?,
                            siege_weapons = ?, cavalry = ?, archers = ?, infantry = ?,
                            navy_ships = ?, army_training = ?, morale = ?,
                            last_updated = CURRENT_TIMESTAMP
                        WHERE house_id = ?
                    ''', (total_food, weapons_quality, armor_quality,
                         total_siege, knights, data['crossbows'], data['soldiers'],
                         total_ships, min(90, data['armor_percentage']), 85, house_id))
                else:
                    # Insert new record
                    c.execute('''
                        INSERT INTO army_resources 
                        (house_id, food_supplies, weapons_quality, armor_quality, 
                         siege_weapons, cavalry, archers, infantry, navy_ships, 
                         army_training, morale)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (house_id, total_food, weapons_quality, armor_quality,
                         total_siege, knights, data['crossbows'], data['soldiers'],
                         total_ships, min(90, data['armor_percentage']), 85))
                
                # Add detailed equipment as house resources (if table exists)
                try:
                    # Try to update equipment details
                    equipment_data = [
                        ('swords', data['swords'], weapons_quality),
                        ('shields', data['shields'], armor_quality),
                        ('crossbows', data['crossbows'], weapons_quality),
                        ('catapults', data['catapults'], 80),
                        ('siege_towers', data['siege_towers'], 70),
                        ('scorpions', data['scorpions'], 75),
                        ('ballistas', data['ballistas'], 85),
                        ('steel', data['steel_equipment'], weapons_quality),
                        ('dried_meat', data['dried_meat_months'] * 1000, 70),
                        ('beer', data['beer_months'] * 1000, 60),
                        ('grain', data['grain_months'] * 1000, 65),
                        ('big_ships', data['big_ships'], 90),
                        ('medium_ships', data['medium_ships'], 80),
                        ('fast_ships', data['fast_ships'], 70),
                        ('long_ships', data['long_ships'], 85)
                    ]
                    
                    # Check if house_resources table exists
                    c.execute('''SELECT name FROM sqlite_master WHERE type='table' AND name='house_resources' ''')
                    if c.fetchone():
                        for resource_type, quantity, quality in equipment_data:
                            c.execute('''
                                INSERT OR REPLACE INTO house_resources 
                                (house_id, resource_type, quantity, quality, last_updated)
                                VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                            ''', (house_id, resource_type, quantity, quality))
                    
                except Exception as e:
                    logger.warning(f"Could not update detailed equipment for {house_name}: {e}")
                
                updated_houses += 1
                logger.info(f"✅ Updated {house_name} - Soldiers: {data['soldiers']}, Quality: {weapons_quality}")
            
            else:
                logger.warning(f"❌ House {house_name} not found in database")
        
        # Commit all changes
        conn.commit()
        logger.info(f"✅ Successfully updated {updated_houses} houses with new army data")
        
        # Display summary
        c.execute('''
            SELECT a.name, a.soldiers, a.army_quality, ar.weapons_quality, ar.armor_quality, ar.siege_weapons, ar.navy_ships
            FROM alliances a
            LEFT JOIN army_resources ar ON a.id = ar.house_id
            ORDER BY a.soldiers DESC
        ''')
        
        print("\n🏰 Updated Army Summary:")
        print("=" * 80)
        for row in c.fetchall():
            name, soldiers, army_qual, weapons, armor, siege, ships = row
            print(f"{name:<15} | Soldiers: {soldiers:>6} | Army: {army_qual or 0:>2}% | Weapons: {weapons or 0:>2} | Armor: {armor or 0:>2} | Siege: {siege or 0:>2} | Ships: {ships or 0:>2}")
        
    except Exception as e:
        logger.error(f"Error updating army data: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    update_house_armies()
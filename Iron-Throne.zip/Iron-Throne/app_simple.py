#!/usr/bin/env python3
import os
import asyncio
import threading
import time
from flask import Flask, jsonify
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create Flask app first for immediate port binding
app = Flask(__name__)

# Bot status tracking
bot_status = {
    'running': False,
    'last_start': None,
    'last_error': None,
    'restart_count': 0
}

# App start time for uptime tracking
app_start_time = None

@app.route('/')
def home():
    return f"""
    <html>
    <head><title>🏰 Iron Throne RP Bot</title></head>
    <body style="font-family: Arial; background: #2c2f33; color: #ffffff; text-align: center; padding: 50px;">
        <h1>🏰 Game of Thrones Discord Bot</h1>
        <h2>⚔️ Iron Throne RP - Demir Taht Roleplay</h2>
        <p>✅ Flask Server: Running</p>
        <p>🤖 Discord Bot: {'Running' if bot_status['running'] else 'Starting/Reconnecting'}</p>
        <p>🔄 Restart Count: {bot_status['restart_count']}</p>
        <p>🏆 167+ Commands | 🏰 10 Houses | ⚔️ Advanced War System</p>
        <p>💰 Economy System | 👑 Marriage System | 🛡️ Auto Moderation</p>
        <hr>
        <p><a href="/status" style="color: #7289da;">Bot Status</a> | <a href="/health" style="color: #7289da;">Health Check</a></p>
        <p><small>Created by xxkaan44xx | Running on Replit</small></p>
    </body>
    </html>
    """

@app.route('/status')
def status():
    return jsonify({
        "status": "running",
        "service": "Iron Throne RP Discord Bot",
        "version": "3.0 Professional Edition",
        "flask_server": "running",
        "bot_running": bot_status['running'],
        "last_start": bot_status['last_start'],
        "last_error": bot_status['last_error'],
        "restart_count": bot_status['restart_count'],
        "commands": "167+",
        "systems": ["War", "Economy", "Marriage", "Tournament", "Trade"],
        "timestamp": time.time()
    })

@app.route('/health')
def health():
    return jsonify({
        "health": "ok",
        "flask": "running",
        "bot": "active" if bot_status['running'] else "starting",
        "port": 5000,
        "uptime": time.time() - app_start_time if app_start_time else 0,
        "last_check": time.time()
    })

def run_discord_bot():
    """Run the Discord bot in a separate thread"""
    while True:  # Keep restarting bot
        try:
            logger.info("Starting Discord bot...")
            bot_status['last_start'] = time.time()
            bot_status['running'] = True
            bot_status['restart_count'] += 1
            
            # Import and run the bot
            from main import main
            
            # Run in this thread's event loop
            asyncio.run(main())
            
        except Exception as e:
            error_msg = f"Bot error: {e}"
            logger.error(error_msg)
            bot_status['running'] = False
            bot_status['last_error'] = str(e)
            logger.info("Bot will restart in 10 seconds...")
            time.sleep(10)
        except KeyboardInterrupt:
            logger.info("Bot shutdown requested")
            bot_status['running'] = False
            break

if __name__ == '__main__':
    logger.info("🏰 Starting Iron Throne RP Bot System...")
    
    # Set start time for uptime tracking
    app_start_time = time.time()
    
    # Start Discord bot in background thread
    bot_thread = threading.Thread(target=run_discord_bot, daemon=True)
    bot_thread.start()
    logger.info("Discord bot thread started")
    
    # Start Flask server on main thread (essential for Replit workflow)
    port = int(os.environ.get('PORT', 5000))
    logger.info(f"Starting Flask web server on 0.0.0.0:{port}")
    
    try:
        app.run(
            host='0.0.0.0',
            port=port,
            debug=False,
            threaded=True,
            use_reloader=False
        )
    except Exception as e:
        logger.error(f"Flask server error: {e}")
        # Keep alive for workflow
        logger.info("Attempting to keep process alive...")
        while True:
            time.sleep(30)
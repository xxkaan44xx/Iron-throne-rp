#!/usr/bin/env python3
"""
Production ready Discord bot with web monitoring for Replit workflows.
This ensures the bot stays running while keeping port 5000 open for workflow monitoring.
"""
import os
import asyncio
import threading
import time
import signal
import sys
from flask import Flask, jsonify

# Import bot components
from main import GameOfThronesBot
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create Flask app for monitoring
app = Flask(__name__)

# Global bot instance and status
bot = None
bot_status = {
    'running': False,
    'ready': False,
    'guilds': 0,
    'commands': 0,
    'start_time': None,
    'last_error': None
}

@app.route('/')
def home():
    uptime = int((time.time() - bot_status['start_time']) / 60) if bot_status['start_time'] else 0
    
    return f"""
    <html>
    <head>
        <title>🏰 Iron Throne RP Bot - Live Status</title>
        <meta http-equiv="refresh" content="20">
        <style>
            body {{ 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #2c2f33, #23272a);
                color: #ffffff; margin: 0; padding: 20px;
            }}
            .container {{ max-width: 900px; margin: 0 auto; }}
            .header {{ text-align: center; margin-bottom: 30px; }}
            .status-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }}
            .status-card {{ 
                background: rgba(35, 39, 42, 0.8); padding: 25px; border-radius: 12px; 
                border: 1px solid #4f545c; box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            }}
            .status-good {{ border-left: 4px solid #43b581; }}
            .status-warning {{ border-left: 4px solid #faa61a; }}
            .status-error {{ border-left: 4px solid #f04747; }}
            .metric {{ margin: 10px 0; }}
            .metric-value {{ font-size: 1.2em; font-weight: bold; }}
            .footer {{ text-align: center; margin-top: 30px; opacity: 0.8; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🏰 Iron Throne RP - Discord Bot</h1>
                <h2>⚔️ Game of Thrones Roleplay System</h2>
            </div>
            
            <div class="status-grid">
                <div class="status-card {'status-good' if bot_status['ready'] else 'status-warning'}">
                    <h3>🤖 Discord Bot Status</h3>
                    <div class="metric">
                        <strong>Status:</strong> 
                        <span class="metric-value">{'🟢 Online & Ready' if bot_status['ready'] else '🟡 Starting...'}</span>
                    </div>
                    <div class="metric">
                        <strong>Guilds:</strong> 
                        <span class="metric-value">{bot_status['guilds']}</span>
                    </div>
                    <div class="metric">
                        <strong>Commands:</strong> 
                        <span class="metric-value">{bot_status['commands']}</span>
                    </div>
                    <div class="metric">
                        <strong>Uptime:</strong> 
                        <span class="metric-value">{uptime} minutes</span>
                    </div>
                </div>
                
                <div class="status-card status-good">
                    <h3>🌐 Web Monitor</h3>
                    <div class="metric">
                        <strong>Port 5000:</strong> 
                        <span class="metric-value">🟢 Active</span>
                    </div>
                    <div class="metric">
                        <strong>Monitoring:</strong> 
                        <span class="metric-value">24/7</span>
                    </div>
                    <div class="metric">
                        <strong>Platform:</strong> 
                        <span class="metric-value">Replit</span>
                    </div>
                </div>
                
                <div class="status-card status-good">
                    <h3>🏆 Bot Features</h3>
                    <div class="metric"><strong>✅ War System</strong> - Strategic battles</div>
                    <div class="metric"><strong>✅ Economy</strong> - Gold, debt, income</div>
                    <div class="metric"><strong>✅ Marriage System</strong> - Alliance building</div>
                    <div class="metric"><strong>✅ RP Characters</strong> - Interactive roleplay</div>
                    <div class="metric"><strong>✅ Auto Moderation</strong> - Server protection</div>
                </div>
                
                <div class="status-card status-good">
                    <h3>📊 System Info</h3>
                    <div class="metric">
                        <strong>Version:</strong> 
                        <span class="metric-value">3.0 Professional</span>
                    </div>
                    <div class="metric">
                        <strong>Houses:</strong> 
                        <span class="metric-value">10 Major Houses</span>
                    </div>
                    <div class="metric">
                        <strong>Database:</strong> 
                        <span class="metric-value">SQLite Active</span>
                    </div>
                </div>
            </div>
            
            <div class="footer">
                <p><a href="/status" style="color: #7289da;">📋 JSON Status</a> | 
                   <a href="/health" style="color: #7289da;">❤️ Health Check</a></p>
                <p><small>Created by xxkaan44xx | Running 24/7 on Replit</small></p>
            </div>
        </div>
    </body>
    </html>
    """

@app.route('/status')
def get_status():
    return jsonify({
        "service": "Iron Throne RP Discord Bot",
        "version": "3.0 Professional Edition",
        "bot_status": {
            "running": bot_status['running'],
            "ready": bot_status['ready'],
            "guilds": bot_status['guilds'],
            "commands": bot_status['commands'],
            "uptime_seconds": int(time.time() - bot_status['start_time']) if bot_status['start_time'] else 0,
            "last_error": bot_status['last_error']
        },
        "web_monitor": {
            "port": 5000,
            "status": "active"
        },
        "features": [
            "167+ Commands",
            "10 Major Houses", 
            "Advanced War System",
            "Economy Management",
            "Marriage System",
            "RP Characters",
            "Auto Moderation",
            "Tournament System",
            "Daily Challenges"
        ],
        "timestamp": time.time()
    })

@app.route('/health')
def health():
    return jsonify({
        "status": "healthy" if bot_status['ready'] else "starting", 
        "web_server": "running",
        "discord_bot": "ready" if bot_status['ready'] else "connecting",
        "port": 5000,
        "uptime": int(time.time() - bot_status['start_time']) if bot_status['start_time'] else 0
    }), 200

async def run_discord_bot():
    """Run the Discord bot with proper error handling"""
    global bot
    
    try:
        logger.info("Initializing Discord bot...")
        bot_status['start_time'] = time.time()
        bot_status['running'] = True
        
        # Get bot token
        bot_token = os.getenv("DISCORD_BOT_TOKEN")
        if not bot_token:
            raise ValueError("DISCORD_BOT_TOKEN not found in environment")
        
        # Create and start bot
        bot = GameOfThronesBot()
        
        # Hook into bot events to update status
        @bot.event
        async def on_ready():
            if bot and bot.user:
                logger.info(f"Bot logged in as {bot.user}")
                bot_status['ready'] = True
                bot_status['guilds'] = len(bot.guilds) if bot.guilds else 0
                bot_status['commands'] = len(bot.commands) if bot.commands else 0
                logger.info(f"Bot ready with {bot_status['commands']} commands in {bot_status['guilds']} guilds")
        
        # Start the bot
        await bot.start(bot_token)
        
    except Exception as e:
        logger.error(f"Bot error: {e}")
        bot_status['last_error'] = str(e)
        bot_status['running'] = False
        bot_status['ready'] = False

def run_bot_thread():
    """Run bot in asyncio event loop"""
    try:
        asyncio.run(run_discord_bot())
    except Exception as e:
        logger.error(f"Bot thread error: {e}")
        bot_status['running'] = False

def signal_handler(signum, frame):
    """Handle shutdown gracefully"""
    logger.info("Shutdown signal received")
    if bot and not bot.is_closed():
        asyncio.create_task(bot.close())
    sys.exit(0)

if __name__ == '__main__':
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logger.info("🏰 Starting Iron Throne RP Bot System...")
    
    # Start Discord bot in background thread
    bot_thread = threading.Thread(target=run_bot_thread, daemon=True)
    bot_thread.start()
    logger.info("Discord bot thread started")
    
    # Give bot a moment to initialize
    time.sleep(2)
    
    # Start Flask web server on main thread
    port = int(os.environ.get('PORT', 5000))
    logger.info(f"Starting web monitor on 0.0.0.0:{port}")
    
    # This MUST stay on main thread for Replit workflow
    app.run(
        host='0.0.0.0',
        port=port,
        debug=False,
        threaded=True,
        use_reloader=False
    )
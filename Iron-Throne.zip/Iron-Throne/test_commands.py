#!/usr/bin/env python3
"""
Test script for Discord bot commands
"""

import sqlite3
import os
import sys
import importlib.util

def test_basic_imports():
    """Test if all essential modules can be imported"""
    essential_modules = [
        'database',
        'commands', 
        'war_system',
        'economy',
        'army_management',
        'tournament_system',
        'main'
    ]
    
    print("🔍 Testing module imports...")
    failed_imports = []
    
    for module in essential_modules:
        try:
            spec = importlib.util.spec_from_file_location(module, f"{module}.py")
            if spec and spec.loader:
                module_obj = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module_obj)
                print(f"✅ {module}.py - OK")
            else:
                print(f"❌ {module}.py - File not found")
                failed_imports.append(module)
        except Exception as e:
            print(f"❌ {module}.py - Error: {e}")
            failed_imports.append(module)
    
    return failed_imports

def test_database_connection():
    """Test database connection and basic queries"""
    print("\n🗄️ Testing database connection...")
    try:
        conn = sqlite3.connect('got_rp.db')
        c = conn.cursor()
        
        # Test basic queries
        c.execute('SELECT COUNT(*) FROM alliances')
        house_count = c.fetchone()[0]
        print(f"✅ Database connected - {house_count} houses found")
        
        c.execute('SELECT name, soldiers FROM alliances ORDER BY soldiers DESC LIMIT 5')
        top_houses = c.fetchall()
        
        print("🏰 Top 5 Houses by Army Size:")
        for house_name, soldiers in top_houses:
            print(f"   {house_name}: {soldiers:,} soldiers")
        
        conn.close()
        return True
    except Exception as e:
        print(f"❌ Database error: {e}")
        return False

def check_command_files():
    """Check if command files exist and are readable"""
    print("\n📁 Checking command files...")
    command_files = [
        'commands.py',
        'easy_commands.py',
        'user_friendly_enhancements.py',
        'achievements_system.py',
        'daily_challenges.py'
    ]
    
    missing_files = []
    for file in command_files:
        if os.path.exists(file):
            try:
                with open(file, 'r', encoding='utf-8') as f:
                    content = f.read()
                    if len(content) > 100:  # Basic sanity check
                        print(f"✅ {file} - OK ({len(content)} chars)")
                    else:
                        print(f"⚠️  {file} - Too small ({len(content)} chars)")
            except Exception as e:
                print(f"❌ {file} - Read error: {e}")
                missing_files.append(file)
        else:
            print(f"❌ {file} - Not found")
            missing_files.append(file)
    
    return missing_files

def check_bot_token():
    """Check if bot token is available"""
    print("\n🔑 Checking bot token...")
    token = os.getenv("DISCORD_BOT_TOKEN")
    if token:
        if len(token) > 50:
            print(f"✅ Bot token available ({len(token)} chars)")
            return True
        else:
            print(f"⚠️  Bot token seems short ({len(token)} chars)")
            return False
    else:
        print("❌ DISCORD_BOT_TOKEN not set")
        return False

def main():
    print("🤖 Discord Bot Command Test Suite")
    print("=" * 50)
    
    # Test imports
    failed_imports = test_basic_imports()
    
    # Test database
    db_ok = test_database_connection()
    
    # Check files
    missing_files = check_command_files()
    
    # Check token
    token_ok = check_bot_token()
    
    print("\n📊 Test Summary:")
    print("=" * 30)
    
    if not failed_imports:
        print("✅ All modules import successfully")
    else:
        print(f"❌ Failed imports: {', '.join(failed_imports)}")
    
    if db_ok:
        print("✅ Database connection working")
    else:
        print("❌ Database connection failed")
    
    if not missing_files:
        print("✅ All command files found")
    else:
        print(f"❌ Missing files: {', '.join(missing_files)}")
    
    if token_ok:
        print("✅ Bot token configured")
    else:
        print("❌ Bot token issue")
    
    # Overall status
    all_ok = not failed_imports and db_ok and not missing_files and token_ok
    
    if all_ok:
        print("\n🎉 All tests passed! Bot should be working correctly.")
    else:
        print("\n⚠️  Some issues found. Bot may have limited functionality.")
    
    return all_ok

if __name__ == "__main__":
    main()